import { ChatInterface } from '@/components/ChatInterface';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-950 flex items-center justify-center p-4">
      <div className="w-full h-[80vh] max-w-4xl mx-auto">
        <ChatInterface />
      </div>
    </div>
  );
}