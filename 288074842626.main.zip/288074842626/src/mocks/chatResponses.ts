// 模拟智能体响应数据
export const chatResponses = {
  greetings: [
    "你好！我是你的智能助手，有什么可以帮助你的吗？",
    "嗨！很高兴见到你，我能为你做些什么？",
    "欢迎！我是你的AI助手，请问有什么我可以帮忙的？"
  ],
  thanks: [
    "不客气！随时为你服务。",
    "很高兴能帮到你！",
    "这是我的荣幸！"
  ],
  default: [
    "我理解你的意思，让我思考一下...",
    "这个问题很有趣，我需要进一步分析。",
    "感谢你的提问，这是一个很好的话题。",
    "让我为你提供更详细的信息。",
    "我正在处理这个问题，请稍等..."
  ],
  help: [
    "我可以帮助你回答问题、提供建议、进行对话交流等。你可以问我任何问题！",
    "我是一个AI助手，我的功能包括：回答问题、提供信息、进行日常对话等。请告诉我你需要什么帮助？",
    "有什么具体需要我帮助的吗？我可以解答问题、提供建议或仅仅是陪你聊天。"
  ]
};

// 根据用户消息生成回复
export const generateResponse = (userMessage: string): string => {
  const lowerMessage = userMessage.toLowerCase();
  
  if (lowerMessage.includes('你好') || lowerMessage.includes('嗨') || lowerMessage.includes('哈喽') || lowerMessage.includes('早上好') || lowerMessage.includes('晚上好')) {
    return chatResponses.greetings[Math.floor(Math.random() * chatResponses.greetings.length)];
  } else if (lowerMessage.includes('谢谢') || lowerMessage.includes('感谢')) {
    return chatResponses.thanks[Math.floor(Math.random() * chatResponses.thanks.length)];
  } else if (lowerMessage.includes('帮助') || lowerMessage.includes('怎么用') || lowerMessage.includes('功能')) {
    return chatResponses.help[Math.floor(Math.random() * chatResponses.help.length)];
  } else {
    return chatResponses.default[Math.floor(Math.random() * chatResponses.default.length)];
  }
};