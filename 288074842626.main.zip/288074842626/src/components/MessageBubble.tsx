import { cn } from "@/lib/utils";

interface MessageBubbleProps {
  content: string;
  isUser: boolean;
  timestamp?: string;
}

export function MessageBubble({ content, isUser, timestamp }: MessageBubbleProps) {
  return (
    <div 
      className={cn(
        "flex mb-4 items-end",
        isUser ? "justify-end" : "justify-start"
      )}
    >
      {!isUser && (
        <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-white mr-2">
          <i className="fa-solid fa-robot"></i>
        </div>
      )}
      <div 
        className={cn(
          "max-w-[80%] p-3 rounded-lg shadow-sm",
          isUser 
            ? "bg-indigo-600 text-white rounded-br-none" 
            : "bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white rounded-bl-none"
        )}
      >
        <p>{content}</p>
        {timestamp && (
          <span className="text-xs opacity-70 block mt-1 text-right">
            {timestamp}
          </span>
        )}
      </div>
      {isUser && (
        <div className="w-8 h-8 rounded-full bg-gray-300 dark:bg-gray-700 flex items-center justify-center ml-2">
          <i className="fa-solid fa-user text-gray-700 dark:text-gray-300"></i>
        </div>
      )}
    </div>
  );
}